from threading import Thread, Lock, Event
from Queue import Queue
from time import sleep
import random

class Event:
	def __init__ (self, etype, edata=None, toall=True):
		self._type  = etype
		self._data  = edata
		self._toall = toall
	
	@property
	def type (self):
		return self._type

	@property
	def data (self):
		return self._data
	
	@property
	def toall (self):
		return self._toall

class Dispatcher:
	def __init__ (self):
		self._listeners = {}
		self._sema      = Lock()

	def dispatch (self, event):
		self._sema.acquire()
		
		if not self.hasListeners(event.type):
			print 'Event', event.type, 'has no listeners'
			self._sema.release()
			return False
		else:
			#print 'Disp | dispatching', event.type, 'to', len(self._listeners[event.type]), 'receipients'
			if event.toall:
				for l in self._listeners[event.type]:
					l.put(event)
			else:
				min(self._listeners[event.type], key=lambda x: x.qsize()).put(event)

		self._sema.release()
		return True

	def hasListeners (self, etype):
		if self._listeners.has_key(etype): return True
		else: return False

	def addListener (self, etype, queue):
		self._sema.acquire()

		if not self.hasListeners(etype):
			self._listeners[etype] = [queue]
		else:
			self._listeners[etype].append(queue)

		self._sema.release()


class EventedWorker (Thread):
	def __init__ (self, dispatcher):
		Thread.__init__(self)
		self.eventQueue = Queue()
		self.dispatcher = dispatcher
		self.responds = []
		self.daemon = True

	def dispatch (self, etype, edata=None, toall=True):
		return self.dispatcher.dispatch(Event(etype,edata,toall))

	def run (self):
		if not self.setup(): return False
		
		for evt in self.responds:
			self.dispatcher.addListener(evt, self.eventQueue)
		
		while True:
			e = self.eventQueue.get()
			if not self.process(e): break

	def setup (self):
		return True

	def process (self, event):
		pass


class BazaBilete (EventedWorker):
	def __init__ (self, dispatcher, nbilete = 100):
		EventedWorker.__init__(self, dispatcher)
		self.responds = ['reg-bilet']
		self.bilete = nbilete

	def process (self, event):
		if event.type == 'reg-bilet':
			if self.bilete < 1:
				print 'Baza | biletele s-au terminat'
				self.dispatch('bilete-nus')
				
			else:
				self.bilete -= 1
				self.dispatch('bilet-emis', event.data)

		return True


class CasaBilete (EventedWorker):
	def __init__ (self, dispatcher, delay = 0.1):
		EventedWorker.__init__(self, dispatcher)
		self.responds = ['cumpara-bilet', 'bilet-emis', 'timpul-expirat', 'bilete-nus']
		self.selling  = None
		self.delay    = delay

	def process (self, event):
		if event.type == 'bilet-emis' and self.selling == event.data:
			self.dispatch('bilet-vindut', event.data)
			self.selling = None
			sleep(self.delay)
		
		elif event.type == 'cumpara-bilet':
			if self.selling == None:
				self.selling = event.data
				self.dispatch('reg-bilet', event.data)
			else:
				self.dispatch('cumpara-bilet', event.data, False)

		elif event.type == 'timpul-expirat':
			print 'Casa se inchide, timpul expirat'
			return False

		elif event.type == 'bilete-nus':
			self.selling = None

		return True


class Calator (EventedWorker):
	def __init__(self, dispatcher):
		EventedWorker.__init__(self, dispatcher)
		self.responds = ['bilet-vindut', 'bilete-nus']
		self.code = random.randint(1000, 9999)

	def setup (self):
		self.dispatch('cumpara-bilet', self.code, False)
		#print 'Trav | ', self.code, 'waiting'
		return True

	def process (self, event):
		if event.type == 'bilet-vindut' and event.data == self.code:
			print 'Trav | ', self.code, 'done'
			return False
		
		elif event.type == 'bilete-nus':
			print 'Trav | ', self.code, 'failed to buy'
			return False

		return True

class Gara (EventedWorker):
	def __init__ (self, dispatcher):
		EventedWorker.__init__(self, dispatcher)
		self.responds = ['nus-bilete']

	def process (self, event):
		if event.type == 'nus-bilete':
			print 'No tickets, gara is activated!'

		return True


class Timeout (EventedWorker):
	def __init__ (self, dispatcher, timeout=5):
		EventedWorker.__init__(self, dispatcher)
		self.timeout = timeout

	def setup (self):
		sleep(self.timeout)
		self.dispatch('timpul-expirat')
		return False


if __name__ == '__main__':
	#TODO: rework selling protocol
	d = Dispatcher()
	BazaBilete(d, 20).start()
	Gara(d).start()
	Timeout(d).start()

	case     = [CasaBilete(d).start() for i in range(0, 6)]
	calatori = [Calator(d).start() for i in range(0,11)]
	#Spawn travelers

	raw_input()

