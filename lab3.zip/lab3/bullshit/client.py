import Pyro4
import lab3

if __name__ == '__main__':
    warehouse = Pyro4.Proxy(raw_input('Enter server URI'))
    janet = lab3.Person("Janet")
    henry = lab3.Person("Henry")
    janet.visit(warehouse)
    henry.visit(warehouse)