import Pyro4
import lab3

if __name__ == '__main__':
    warehouse = lab3.Warehouse()
    Pyro4.Daemon.serveSimple(
            {
                warehouse: "example.warehouse"
            },
            ns=False
    )