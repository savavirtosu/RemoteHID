from threading import Thread, Semaphore, Event
from Queue import Queue
from time import sleep
import random
'''
Intr-o agentie CFM sunt 6 case de bilete, de la fiecare casa se emit bilete pentru orice destinatie. 
Pentru ca doua case sa nu vanda acelasi loc deodata, fiecare casierita (de fapt terminalul ei) blocheaza baza de date cu trenuri, 
vinde biletul si apoi o deblocheaza. Intre doua vanzari de bilete (adica intre doi clienti) trece un interval arbitrar de timp. 

Daca s-au vandut toate biletele (N bilete), agentia telefoneaza la gara pentru a comunica acest lucru 
(adica folosind o variabila conditionala se 'activeaza' threadul 'gara' ). 
De asemenea daca nu s-au vandut toate biletele dar a trecut un interval de timp prestabilit, 
gara telefoneaza agentiei pentru a nu mai vinde bilete (adica threadul 'gara' va termina threadurile 'case de bilete').
'''
class StationDB:
    def __init__ (self, tickets = {}):
        self.tickets = tickets
        self.s = Semaphore(1)
        self.__noTickets = False

    def noTickets (self):
        self.s.acquire()

        self.__noTickets = True
        for k in self.tickets.keys():
            if self.tickets[k] > 0:
                self.__noTickets = False
                break
        
        status = self.__noTickets
        self.s.release()

        return status

    def hasTickets (self, route):
        self.s.acquire()
        status = self.tickets[route] > 0
        self.s.release()

        return status

    def sell (self, route):
        self.s.acquire()

        if self.__noTickets:
            return False
        
        if self.tickets.has_key(route):
            ticket = self.tickets[route]
            if ticket > 0:
                ticket -= 1
            else:
                return False

        self.s.release()


class TrainStation:
    def __init__ (self, cassesCount = 6, maxWaitSales = 100, db = {}):
        self.db = StationDB(db)
        self.qs = [Queue() for i in range(0,cassesCount)]
        self.casses = [TicketCass(self.db, q) for q in self.qs]
        self.maxWaitSales = maxWaitSales
        self.s = Semaphore(1)
        self.id = 1000
        
    def casasQueues (self):
        self.s.acquire()
        qs = [c.q.qsize() for c in self.casses]
        self.s.release()

        return qs

    def buyFrom (self, casaId, route):
        if not self.db.noTickets():
            self.s.acquire()

            if self.db.hasTickets(route):
                self.qs[casaId].put(route)
                self.s.release()
                return True
            else:
                return False
        else:
            return False


    def start (self):
        for c in self.casses:
            c.start()
        


class TicketCass (Thread):
    def __init__ (self, db, q):
        Thread.__init__(self)
        self.db = db
        self.q = q

    def run (self):
        while True:
            packet = self.q.get()
            print 'TicketCass | packet', packet
            if packet == 0xDEADBEEF:
                break
            else:
                status = self.db.sell(packet)
            
            sleep(1)


class Traveler (Thread):
    def __init__ (self, station, route):
        Thread.__init__(self)
        self.station = station
        self.route = route

    def run (self):
        print 'Traveler | Trying to buy ticktet', self.route
        qs = self.station.casasQueues()
        casa = qs.index(max(qs))
        #print 'Traveler |', qs, casa

        if self.station.buyFrom(casa, self.route):
            print 'Traveler | Bought the ticket'
        else:
            print 'Traveler | No tickets for me, duh'
        


if __name__ == '__main__':
    station = TrainStation(db = {
        'balti-chisinau' : 10,
        'chisinau-taraclia' : 5,
        'bati-chimislia' : 15
    })

    station.start()
    
    routes = ['balti-chisinau', 'chisinau-taraclia', 'bati-chimislia']
    for t in range(0,10):
        t = Traveler(station, 'chisinau-taraclia')
        t.start()
